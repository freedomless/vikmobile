# Tabris.js Firebase Plugin

The Tabris.js Firebase Plugin documentation consists of the following pages:

* [Firebase Cloud Messaging](cloud-messaging.md)
* [Firebase Analytics](analytics.md)
