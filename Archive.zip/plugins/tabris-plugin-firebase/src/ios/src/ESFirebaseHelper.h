//
//  ESFirebase.h
//  Tabris.js Firebase Plugin Example
//
//  Created by Patryk Mol on 13.11.17.
//

#import <UIKit/UIKit.h>

@interface ESFirebaseHelper : NSObject

+ (void)setup;

@end
